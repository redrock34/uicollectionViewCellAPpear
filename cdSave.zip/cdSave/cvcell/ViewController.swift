//
//  ViewController.swift
//  cvcell
//
//  Created by Max Nelson on 6/1/19.
//  Copyright © 2019 Maxcodes. All rights reserved.
//

import UIKit
import CoreData


class ViewController: UIViewController {
      var itemName : [NSManagedObject] = []

    
    fileprivate let collectionView:UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .vertical
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.translatesAutoresizingMaskIntoConstraints = false
        cv.register(CustomCell.self, forCellWithReuseIdentifier: "cell")
        return cv
    }()
    
    var backButton = UIButton()
    @objc func moveLeft() {
        
        
        let vc = reViewController()
        self.present(vc, animated: true)
        
        
        
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.systemPurple
        view.addSubview(collectionView)
        backButton.translatesAutoresizingMaskIntoConstraints = false
        
        backButton.backgroundColor = UIColor.systemGray
        backButton.setTitle("back", for: .normal)
        view.backgroundColor = UIColor.systemTeal
        
        collectionView.backgroundColor = .white
        collectionView.delegate = self
        collectionView.dataSource = self
        
        
        collectionView.topAnchor.constraint(equalTo: view.topAnchor, constant: 10).isActive = true
        collectionView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 40).isActive = true
        collectionView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -40).isActive = true
        collectionView.heightAnchor.constraint(equalToConstant: view.frame.width/0.8).isActive = true
        
        
            view.addSubview(backButton)
        
            backButton.addTarget(self, action: #selector(moveLeft), for: .touchUpInside)
            
        
     
        NSLayoutConstraint.activate ([
                   backButton.trailingAnchor.constraint(equalTo: view.centerXAnchor, constant :0),
                   backButton.topAnchor.constraint(equalTo: view.centerYAnchor, constant : 150),
                   backButton.widthAnchor.constraint(equalToConstant: 75),
                   backButton.heightAnchor.constraint(equalToConstant: 50),
        
        ])
        
    }



}

extension ViewController: UICollectionViewDelegateFlowLayout, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.frame.width/2.5, height: collectionView.frame.width/2)
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return itemName.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! CustomCell
        
        let title = itemName[indexPath.row]
               let attr1 = title.value(forKey: "atBATS") as? String
             
        let text = [" : ", attr1].compactMap { $0 }.reduce("", +)
        
        
        
           cell.tt.text = " \(indexPath.row+1) \(text)"
        cell.backgroundColor = UIColor.orange
        return cell
        
        
    }
}

class CustomCell: UICollectionViewCell {
              
    

    var  bg: UIImageView = {
       let iv = UIImageView()
        iv.translatesAutoresizingMaskIntoConstraints = false
        iv.contentMode = .scaleAspectFill
        iv.clipsToBounds = true
                iv.layer.cornerRadius = 0
        return iv
    }()
    
    var  bt: UIButton = {
       let bt = UIButton()
        bt.translatesAutoresizingMaskIntoConstraints = false
        bt.contentMode = .scaleAspectFill
        bt.clipsToBounds = true
                bt.layer.cornerRadius = 0
        return bt
    }()
    
    
    var  bt2: UIButton = {
       let bt2 = UIButton()
        bt2.translatesAutoresizingMaskIntoConstraints = false
        bt2.contentMode = .scaleAspectFill
        bt2.clipsToBounds = true
                bt2.layer.cornerRadius = 0
        return bt2
    }()
    
    
    var  tt: UILabel = {
       let tt = UILabel()
        tt.translatesAutoresizingMaskIntoConstraints = false
        tt.contentMode = .scaleAspectFill
        tt.clipsToBounds = true
              
        return tt
    }()
    
    override init(frame: CGRect) {
        super.init(frame: .zero)
        
        [bt2,bt,bg,tt].forEach({
            $0.translatesAutoresizingMaskIntoConstraints = false
            self.contentView.addSubview($0)
        })

        bt.backgroundColor = UIColor.systemPink
        bt2.backgroundColor = UIColor.systemTeal
        bt.setTitle("show", for: .normal)
        bt2.setTitle("delete", for: .normal)
        tt.text = "cnn"
        
        
        NSLayoutConstraint.activate ([
              
            bg.trailingAnchor.constraint(equalTo: contentView.centerXAnchor, constant :20),
                  bg.topAnchor.constraint(equalTo: contentView.centerYAnchor, constant : 0),
                  bg.widthAnchor.constraint(equalToConstant: 60),
                  bg.heightAnchor.constraint(equalToConstant: 60),
                  
                  
                  tt.trailingAnchor.constraint(equalTo: contentView.centerXAnchor, constant :20),
                                 tt.topAnchor.constraint(equalTo: contentView.centerYAnchor, constant : -60),
                                 tt.widthAnchor.constraint(equalToConstant: 40),
                                 tt.heightAnchor.constraint(equalToConstant: 60),
                  
                  
                  bt.trailingAnchor.constraint(equalTo: contentView.centerXAnchor, constant :-20),
                                bt.topAnchor.constraint(equalTo: contentView.centerYAnchor, constant : 20),
                                bt.widthAnchor.constraint(equalToConstant: 60),
                                bt.heightAnchor.constraint(equalToConstant: 60),
                                
                                
                                bt2.trailingAnchor.constraint(equalTo: contentView.centerXAnchor, constant :60),
                                                            bt2.topAnchor.constraint(equalTo: contentView.centerYAnchor, constant : 20),
                                                            bt2.widthAnchor.constraint(equalToConstant: 60),
                                                            bt2.heightAnchor.constraint(equalToConstant: 60),
        
        
        ])


    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

class reViewController: UIViewController {
    
    var nextPage = UIButton()
    
    var submitToDB = UIButton()
    

    
    
    var itemName : [NSManagedObject] = []
    
    var myLayer = CALayer()
    var path = UIBezierPath()
    var startPoint = CGPoint()
    var touchPoint = CGPoint()
    
    
    
    var playName = UITextField()
    
    
    
    
    
    var drawPlace = UIImageView()//The imageview
    
    
    
    
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        let touch = touches.first
        if let point = touch?.location(in: drawPlace){
            startPoint = point
            
        }
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        let touch = touches.first
        if let point = touch?.location(in: drawPlace){
            touchPoint = point
        }
        
        path.move(to: startPoint)
        path.addLine(to: touchPoint)
        startPoint = touchPoint
        draw()
    }
    func draw() {
        submitToDB.layer.cornerRadius = 0
        drawPlace.clipsToBounds = true
        drawPlace.isMultipleTouchEnabled = false
        let strokeLayer = CAShapeLayer()
        strokeLayer.fillColor = nil
        strokeLayer.lineWidth = 2
        strokeLayer.strokeColor = UIColor.blue.cgColor
        strokeLayer.path = path.cgPath
        drawPlace.layer.insertSublayer(strokeLayer, below: myLayer)
        drawPlace.setNeedsDisplay()
        
        
       
        
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = UIColor.brown
     
        submitToDB.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(submitToDB)
        
        
        nextPage.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(nextPage)
        
        drawPlace.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(drawPlace)
        
        playName.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(playName)
        
        
        
        
        
        draw()
        
        
        
 
        submitToDB.setTitle("Submit", for: .normal)
        nextPage.setTitle("next", for: .normal)
        submitToDB.backgroundColor = UIColor.purple
        drawPlace.backgroundColor = UIColor.orange
        playName.backgroundColor = UIColor.orange
        playName.placeholder = "enter name"
        playName.textAlignment = .center
        nextPage.backgroundColor = UIColor.gray
        NSLayoutConstraint.activate ([
            submitToDB.trailingAnchor.constraint(equalTo: view.centerXAnchor, constant :37.5),
            submitToDB.topAnchor.constraint(equalTo: view.centerYAnchor, constant : 225),
            submitToDB.widthAnchor.constraint(equalToConstant: 75),
            submitToDB.heightAnchor.constraint(equalToConstant: 50),
            
            nextPage.trailingAnchor.constraint(equalTo: view.centerXAnchor, constant :37.5),
            nextPage.topAnchor.constraint(equalTo: view.centerYAnchor, constant : 280),
            nextPage.widthAnchor.constraint(equalToConstant: 75),
            nextPage.heightAnchor.constraint(equalToConstant: 50),
            
            
    
            
            
            playName.trailingAnchor.constraint(equalTo: view.centerXAnchor, constant :75),
            playName.topAnchor.constraint(equalTo: view.centerYAnchor, constant : -275),
            playName.widthAnchor.constraint(equalToConstant: 150),
            playName.heightAnchor.constraint(equalToConstant: 50),
            
 
            
            ])

        submitToDB.addTarget(self, action: #selector(submitAction), for: .touchUpInside)
        nextPage.addTarget(self, action: #selector(moveRight), for: .touchUpInside)
        
    }
    @objc func moveRight() {
        
        
        let vc = ViewController()
        self.present(vc, animated: true)
        
        
        
        
    }
    
    
    func saver(text: String) {
      
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let managedContext = appDelegate.persistentContainer.viewContext
        let entity = NSEntityDescription.entity(forEntityName: "Item", in: managedContext)!
        let item = NSManagedObject(entity: entity, insertInto: managedContext)
        let fetch = NSFetchRequest<NSFetchRequestResult>(entityName: "Item")
        
        
       
        
        
        item.setValue(text, forKey: "atBATS")
        
        do {
            let result = try? managedContext.fetch(fetch) as? [Item]
            print("Queen",result?.count)
            try? managedContext.save()
            
            print("Text = \(text)")
            
        }
        catch {
            print("Could not save")
        }
        
    }
    
    
    
    @objc func clearAction() {
        
        path.removeAllPoints()
        drawPlace.layer.sublayers = nil
        drawPlace.setNeedsDisplay()
        
        
        playName.text = ""
        
        
        
        
        
        
        
    }
    @objc func submitAction() {
        
        
        if let textEntered = self.playName.text {
            if textEntered.isEmpty != true {
                saver(text: textEntered)
                print("Saves the textfield text")
            } else { print("Text Field was empty nothing to save.")}
        } else {  print("The text field was nil")
        }
        
        playName.resignFirstResponder()
        
        clearAction()
        
        
        
    }
    
    
    
    
}

//CoreData string not fetching and appearing in uicollectionviewcell


//My code has two view controllers. The first view controller saves a string to core data. The 2nd view controller should display the string on a label in a uicollectionview cell. The probelm is that in the 2nd view controller no collectionviewcell is even appearing. The string is not being displayed.

